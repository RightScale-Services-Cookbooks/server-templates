#
# Cookbook:: rsc_jenkins
# Recipe:: slave
#
# Copyright:: 2017, The Authors, All Rights Reserved.

include_recipe 'java::default'

# Create the Jenkins user
user node['rsc_jenkins']['slave']['user'] do
  home node['rsc_jenkins']['slave']['home']
  system node['rsc_jenkins']['slave']['use_system_accounts']
end

# Create the Jenkins group
group node['rsc_jenkins']['slave']['group'] do
  members node['rsc_jenkins']['slave']['user']
  system node['rsc_jenkins']['slave']['use_system_accounts']
end

# Create the home directory
directory node['rsc_jenkins']['slave']['home'] do
  owner     node['rsc_jenkins']['slave']['user']
  group     node['rsc_jenkins']['slave']['group']
  mode      '0755'
  recursive true
end

# Create the fsroot directory
directory node['rsc_jenkins']['slave']['fsroot'] do
  owner     node['rsc_jenkins']['slave']['user']
  group     node['rsc_jenkins']['slave']['group']
  mode      '0755'
  recursive true
end

include_recipe 'runit::default'

# Download Swarm Client
remote_file File.join(node['rsc_jenkins']['slave']['home'], 'swarm-client.jar') do
  source   node['rsc_jenkins']['swarm']['source']
  owner    node['rsc_jenkins']['slave']['user']
  group    node['rsc_jenkins']['slave']['group']
  notifies :restart, 'runit_service[swarm_client]'
end

runit_service 'swarm_client' do
  log true
  default_logger true
end
