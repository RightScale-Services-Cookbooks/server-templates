#
# Cookbook:: rsc_jenkins
# Recipe:: master
#
# Copyright:: 2017, The Authors, All Rights Reserved.

include_recipe 'java::default'
include_recipe 'jenkins::master'
