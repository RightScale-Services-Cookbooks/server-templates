name 'build_cookbook'
maintainer 'RightScale,'
maintainer_email 'you@example.com'
license 'apachev2'
version '0.1.0'

depends 'delivery-truck'
