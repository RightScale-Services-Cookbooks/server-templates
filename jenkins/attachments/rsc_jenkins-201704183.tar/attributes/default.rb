default['java']['install_flavor'] = 'openjdk'
default['java']['jdk_version'] = '8'
default['java']['set_etc_environment'] = true

default['rsc_jenkins']['slave-setup']['version'] = '1.10'

default['rsc_jenkins']['swarm']['version'] = '3.4'
default['rsc_jenkins']['swarm']['source'] = "https://repo.jenkins-ci.org/releases/org/jenkins-ci/plugins/swarm-client/#{node['rsc_jenkins']['swarm']['version']}/swarm-client-#{node['rsc_jenkins']['swarm']['version']}.jar"
