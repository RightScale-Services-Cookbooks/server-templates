#
# Cookbook:: rsc_jenkins
# Recipe:: slave_setup_plugin
#
# Copyright:: 2017, The Authors, All Rights Reserved.

# ssh_private_key "jenkins" do
#   source 'chef-vault'
#   layout 'simple'
# end

jenkins_plugin 'slave-setup' do
  version node['rsc_jenkins']['slave-setup-version']
  notifies :restart, 'service[jenkins]', :immediately
end
