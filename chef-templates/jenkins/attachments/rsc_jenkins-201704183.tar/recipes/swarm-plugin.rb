#
# Cookbook:: rsc_jenkins
# Recipe:: swarm-plugin
#
# Copyright:: 2017, The Authors, All Rights Reserved.

jenkins_plugin 'swarm' do
  version node['rsc_jenkins']['swarm']['version']
  install_deps true
  notifies :restart, 'service[jenkins]', :immediately
end
