name 'rsc_jenkins'
maintainer 'RightScale, Inc'
maintainer_email 'cookbooks@rightscale.com'
license 'apachev2'
description 'Installs and configured Jenkins master and slave servers'
long_description 'Installs/Configures Jenkins for use with Rightscale'
version '0.1.0'

# The `issues_url` points to the location where issues for this cookbook are
# tracked.  A `View Issues` link will be displayed on this cookbook's page when
# uploaded to a Supermarket.
#
# issues_url 'https://github.com/<insert_org_here>/rsc_jenkins/issues' if respond_to?(:issues_url)

# The `source_url` points to the development reposiory for this cookbook.  A
# `View Source` link will be displayed on this cookbook's page when uploaded to
# a Supermarket.
#
source_url 'https://github.com/rs-services/rsc_jenkins' if respond_to?(:source_url)

recipe 'rsc_jenkins','Install Jenkins Master'
recipe 'rsc_jenkins::slave_setup_plugin', 'Install/Configure Slave SetupPlugin for use with RightScale'
recipe 'rsc_jenkins::master','Install Jenkins Master'
recipe 'rsc_jenkins::slave','Install Jenkins Slave'

depends 'jenkins', '~>5.0'
depends 'java', '~>1.48'
depends 'ssh-private-keys', '~> 2.0.0'
depends 'ssh_authorized_keys', '~> 0.3.0'
